//
//  MyCustomRow.swift
//  LohmanSean_CE02 WatchKit Extension
//
//  Created by Sean Lohman on 5/13/18.
//  Copyright © 2018 Sean Lohman. All rights reserved.
//

import Foundation
import WatchKit

class CustomRow: NSObject {
    @IBOutlet var rowImage: WKInterfaceImage!
}
