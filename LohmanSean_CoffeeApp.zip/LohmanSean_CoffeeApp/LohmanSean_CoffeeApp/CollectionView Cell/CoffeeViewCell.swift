//
//  CoffeeViewCell.swift
//  LohmanSean_CoffeeApp
//
//  Created by Sean Lohman on 5/14/18.
//  Copyright © 2018 Sean Lohman. All rights reserved.
//

import UIKit

class CoffeeViewCell: UICollectionViewCell {
    
    @IBOutlet weak var coffeeImage: UIImageView!
    @IBOutlet weak var sizeLabel: UILabel!
    
}
